#include <stdlib.h>
#include <stdbool.h>
#include "winning.h"
#include "board.h"

bool is_game_over(char** board, int rows, int cols, char blank_space, int win_pieces){
    return has_a_player_won(board, rows, cols, blank_space, win_pieces) || 
           is_tie_game(board, rows, cols, blank_space, win_pieces);
}

bool has_a_player_won(char** board, int rows, int cols, char blank_space, int win_pieces){
    return has_a_player_won_horizontally(board, rows, cols, blank_space, win_pieces) ||
           has_a_player_won_vertically(board, rows, cols, blank_space, win_pieces) ||
           has_a_player_won_diagonally(board, rows, cols, blank_space, win_pieces); 
}

bool has_a_player_won_horizontally(char** board, int rows, int cols, char blank_space, int win_pieces){
    //If any of the rows are filled entirely with 1 player’s piece

    for(int i = 0; i < rows; ++i){
        for(int j = 0; j < cols; ++j){
            if(contains_win(board[i]+j, win_pieces, blank_space)){
                return true;
            }
        }
    }
    return false; 

}

bool has_a_player_won_vertically(char** board, int rows, int cols, char blank_space, int win_pieces){
    //If any of the columns are filled entirely with 1 player’s piece
    
    for(int i = 0; i < cols; ++i){
            char* cur_col = get_column(board, rows, i);
            bool is_win = false;
            for(int j = 0; j < rows; ++j){
                if(contains_win(cur_col + j, win_pieces, blank_space)){
                    is_win = true;
                    break;
                }
            }
            //bool is_win = contains_win(cur_col, cols, blank_space);
            free(cur_col);
            if(is_win){
                return true;
            }
        
    }

    return false;
}

bool has_a_player_won_diagonally(char** board, int rows, int cols, char blank_space, int win_pieces){
    //If any of the two main diagonals are filled entirely with 1 player’s piece
    bool is_win;
    for(int i = 0; i < (rows); ++i){
        for(int j = 0; j<cols; ++j){
            char* left_diagonal = get_left_diagonal(board, rows, cols, i, j);
            char* right_diagonal = get_right_diagonal(board, rows, cols, i, j);
            is_win =  contains_win(left_diagonal, win_pieces, blank_space) || 
                        contains_win(right_diagonal, win_pieces, blank_space);
            free(left_diagonal);
            free(right_diagonal);
            if(is_win){
                break;
            }
        }
        if(is_win){
            break;
            }
    }
    return is_win;
}



// bool has_a_player_won_vertically_alt(char** board, int dimensions, char blank_space){
//     //If any of the columns are filled entirely with 1 player’s piece
//     bool all_same;
//     for(int col = 0; col < dimensions; ++col){
//         all_same = true;
//         if(board[0][col] == blank_space){
//             continue;
//         }
//         for(int row = 1; row < dimensions; ++ row){
//             if(board[row][col] != board[0][col]){
//                 all_same = false
//                 break;
//             }
//         }
//         if(all_same){
//             return true;
//         }
//     }
//     return false; 
      
// }



bool contains_win(char* sequence, int length , char blank_space){
    return are_all_same(sequence, length) && sequence[0] != blank_space;
}
//sequence[0] != blank_space &&

bool are_all_same(char* str, int len){
    for(int i = 1; i < len; ++i){
        if(str[i] != str[0]){
            return false;
        }
    }
    return true; 
}

bool is_tie_game(char** board, int rows, int cols, char blank_space, int win_pieces){
    //If the board is full and no one has won
    for(int i = 0; i < rows; ++i){
        for(int j = 0; j < cols; ++j){
            if(board[i][j] == blank_space){
                return false;
            }
        }
    }
    return !has_a_player_won(board, rows, cols, blank_space, win_pieces);
}