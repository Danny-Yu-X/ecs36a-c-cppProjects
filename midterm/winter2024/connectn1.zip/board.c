#include <stdlib.h>
#include <stdio.h>
#include "board.h"

char** make_grid(int rows, int cols, char blank_space){
    /*
    Make a N X N empty tic tac toe board
    */
    char** board = (char**)malloc(rows * sizeof(char*));
    for(int i = 0; i < rows; ++i){
        board[i] = (char*) malloc((cols+1) * sizeof(char));   //potential issue
        for(int j = 0; j < cols; ++j){
            board[i][j] = blank_space;
        }
        
    }

    return board;
}

void destroy_board(char** board, int dimensions){
    for(int i = 0; i < dimensions; ++i){
        free(board[i]);
    }
    free(board);
}

void display_board(char** board, int rows, int cols){
    //display the column headers
    
    for(int i = 0; i < rows; ++i){
        printf("%d ", rows-(i+1));
        for(int j = 0; j < cols; ++j){
            printf("%c ", board[i][j]);
        }
        printf("\n");
    }
    printf("  ");
    for(int i = 0; i < cols;++i){
        printf("%d ", i);
    }
    printf("\n");
}

char* get_column(char** board, int dimensions, int column_index){
    char* cur_col = (char*)malloc(dimensions * sizeof(char));
    for(int i = 0; i < dimensions; ++i){
        cur_col[i] = board[i][column_index]; 
    }
    return cur_col;
}

char* get_left_diagonal(char** board, int rows, int cols, int indexRow, int indexCol){
    /* Get this diagonal pictured below 
        X
          X
            X
    */
    int diagonal_length = (rows < cols) ? rows : cols;
    char* diagonal = (char*)malloc(diagonal_length * sizeof(char));
    int diagonal_index = 0;

    // Iterate over the diagonal elements
    while (indexRow < rows && indexCol < cols && diagonal_index < diagonal_length) {
        // Store the current diagonal element in the diagonal array
        diagonal[diagonal_index] = board[indexRow][indexCol];

        // Move to the next element along the diagonal
        indexRow++;
        indexCol++;
        diagonal_index++;
    }
    return diagonal;
}

char* get_right_diagonal(char** board, int rows, int cols, int indexRow, int indexCol){
    /* Get this diagonal pictured below 
            X
          X
        X
    */
   int diagonal_length = (rows < cols) ? rows : cols;
    char* diagonal = (char*)malloc(rows * sizeof(char));
    int diagonal_index = 0;

    // Iterate over the diagonal elements
    while (indexRow < rows && indexCol >= 0 && diagonal_index < diagonal_length) {
        // Store the current diagonal element in the diagonal array
        diagonal[diagonal_index] = board[indexRow][indexCol];

        // Move to the next element along the diagonal
        indexRow++;
        indexCol--;
        diagonal_index++;
    }

    /*for(int row = 0, col = cols - 1; row < rows; ++row, --col){
        diagonal[row] = board[row][col];
        // board[row][dimensions - row - 1]
    }*/
    return diagonal;
}