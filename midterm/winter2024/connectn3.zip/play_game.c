#include <stdio.h>
#include <stdbool.h>
#include "board.h"
#include "play_game.h"
#include "winning.h"
#include "input_validation.h"

int switch_to_next_player(int cur_player_turn){
    if(cur_player_turn == 0){
        return 1;
    }else{
        return 0;
    }

    // (cur_player_turn + 1) % num_players

}

void announce_results(char** board, int rows, int cols, char blank_space, int cur_player_turn, int win_pieces){
    display_board(board, rows, cols);
    if(has_a_player_won(board, rows, cols, blank_space, win_pieces)){
        if(cur_player_turn == 0){
            printf("Player 1 Won!");
        }else{
            printf("Player 2 Won!");
        }
    }else{
        printf("Tie game!");
    }
}

void play_game(char** board, int rows, int cols, int win_pieces, char blank_space, char* player_pieces, int cur_player_turn){
    while(true){
        current_player_take_turn(board, rows, cols, blank_space, cur_player_turn, player_pieces[cur_player_turn]);
        if(is_game_over(board, rows, cols, blank_space, win_pieces)){
            break;
        }
        cur_player_turn = switch_to_next_player(cur_player_turn);
    }
    //cur_player_turn = switch_to_next_player(cur_player_turn);
    announce_results(board, rows, cols, blank_space, cur_player_turn, win_pieces);
}



void current_player_take_turn(char** board, int rows, int cols, char blank_space, int cur_player_turn, char cur_players_piece){
    /*
        Player chooses an empty spot on the grid
        Player places their piece on the chosen spot
    */
    int col;
    int row;
    display_board(board, rows, cols);
    get_valid_player_spot_to_play(board, rows, cols, blank_space, cur_player_turn, &col);
    for (row = rows - 1; row >= 0; --row) {
    if (board[row][col] == blank_space) { // Check if the cell is empty
        board[row][col] = cur_players_piece; // Place the player's piece
        break; // Exit the loop after placing the piece
    }//gravity
}

}

void  get_valid_player_spot_to_play(char** board, int rows, int cols, char blank_space, int cur_player_turn, int *col){
    int num_args_read;
    do{
        printf("Enter a column between 0 and %d to play in: ", cols - 1);
        num_args_read = scanf("%d", col);
        //printf("NumArgRead %d ", *col);
    }while(!is_valid_spot_to_play(board, rows, cols, blank_space, *col, num_args_read));
}

bool is_valid_spot_to_play(char** board, int rows, int cols, char blank_space, int col, int num_args_read){
    if (!isValidFormat(num_args_read, 1) || !is_on_board(col, cols)) {
        return false;
    }
    //int row = 0;
    // Check if the chosen spot is empty (i.e., equal to blank_space)
    if (board[0][col] != blank_space) {
        //printf("That column is already filled. Please choose another column.\n");
        return false;
    }

    // If all conditions are met, the spot is valid to play
    return true;
}

bool is_on_board(int col, int cols){
    //printf("is on board");
    return is_between(col, 0, cols-1);
}

bool is_between(int value, int min_value, int max_value){
    /*
        check if value is in [min_value, max_value], both inclusive
    */
   //printf("is between");
    return value >= min_value && value <= max_value;
}