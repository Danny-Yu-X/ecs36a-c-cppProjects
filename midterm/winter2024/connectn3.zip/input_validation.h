
#ifndef INPUT_VALIDATION_H
    #define INPUT_VALIDATION_H
    bool isValidFormat(const int numArgsRead, const int numArgsNeed);
# endif