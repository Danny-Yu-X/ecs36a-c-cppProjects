#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "paint.h"
#include "backend.h"

void print_help(){

  printf("Commands:\n");
  printf("Help: h\n");
  printf("Quit: q\n");
  printf("Draw line: w row_start col_start row_end col_end\n");
  printf("Resize: r num_rows num_cols\n");
  printf("Add row or column: a [r | c] pos\n");
  printf("Delete row or column: d [r | c] pos\n");
  printf("Erase: e row col\n");
  printf("Save: s file_name\n");
  printf("Load: l file_name\n");
}

bool isBigZero(int num) {
    return num >= 0; 
}
void clearBuffer() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}
void userInput(struct Canvas *canvas) {
    char command;
    int startRow, startCol, endRow, endCol, pos, newRows, newCols;
    char type;
    char fileName[100];

    printf("Enter your command: ");
    scanf(" %c ", &command);

    switch (command){
        case 'q':
            freeCanvas(canvas);
            clearBuffer();
            exit(0);
        case 'h':
            print_help();
            clearBuffer();
            break;
        case 'w':
            if(scanf("%d %d %d %d", &startRow, &startCol, &endRow, &endCol) == 4) {
                if(isBigZero(startRow) && isBigZero(startCol) && isBigZero(endRow) && isBigZero(endCol)) {
                    makeLine(canvas, startRow, startCol, endRow, endCol);
                } else {
                    printf("Please fix line 45 userInput.c");//error msg
                }
            }else{
                printf("Fix line 48, userinput.c");//error
            }
            clearBuffer();
            break;
        case 'e':
            if (scanf("%d %d", &startRow, &startCol) == 2) {
                if(isBigZero(startRow) && isBigZero(startCol)){
                    eraseCell(canvas, startRow, startCol);
                }else{
                    printf("56, userinput.c");
                }
            }else{
                printf("59 userinput.c");
            }
            clearBuffer();
            break;
        case 'r':
            if(scanf("%d %d", &newRows, &newCols) == 2) {
                if (isBigZero(newRows) && isBigZero(newCols)){
                    resize(canvas, newRows, newCols);
                }else{
                    printf("67 userinput");
                }
            }else{
                printf("70 userinput");
            }
            clearBuffer();
            break;
        case 'a':
            if (scanf(" %c %d", &type, &pos) == 2) {
                if ((type == 'r' || type == 'c') && isBigZero(pos)) {
                    add(canvas, type, pos);
                } else {
                    printf("78 userinput");
                }
            } else {
                printf("81 userinput");
            }
            clearBuffer();
            break;
        case 'd':
            if (scanf(" %c %d", &type, &pos) == 2) {
                if ((type == 'r' || type == 'c') && isBigZero(pos)) {
                    deleteRC(canvas, type, pos);
                } else {
                    printf("89 userinput");
                }
            } else {
                printf("92 user input");
            }
            clearBuffer();
            break;
        case 's':
            if (scanf("%s", fileName) == 1) {
                saveCanvas(canvas, fileName);
            } else {
                printf("99 userinput");
            }
            clearBuffer();
            break;
        case 'l':
            scanf("%s", fileName);
            loadCanvas(canvas, fileName);
            clearBuffer();
            break;
        default:
            clearBuffer();
            break;    
    }

}