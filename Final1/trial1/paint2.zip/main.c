#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "backend.h"
#include "userInput.h"

int main(int argc, char *argv[]) {

    struct Canvas *canvas = (struct Canvas *)malloc(sizeof(struct Canvas));
    if (argc == 3){
        if(*argv[1]>=1 && *argv[2]>=1){
            int rows = atoi(argv[1]);
            int cols = atoi(argv[2]);
            makeCanvas(canvas, rows, cols);
        }else{
            makeCanvas(canvas, 10, 10);
        }
    }else{
        makeCanvas(canvas, 10, 10);
    }
    
    while(true){
        outputCanvas(canvas);
        userInput(canvas);
    }
    return 0;
}
